# Description

The resource is responsible for ensuring that Windows Update Agent
configuration for using Microsoft Update.
